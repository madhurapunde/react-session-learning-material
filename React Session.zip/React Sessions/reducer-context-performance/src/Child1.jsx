
const Child1 = ({inc})=>{
    console.log("Child-1 is rendering")
    return(
        <div>
            Child-1
            <button onClick={inc}>Increment Child-1</button>
        </div>
    )
}

export default Child1