
import React from 'react'

const Child2 = ({val})=>{
    console.log("Child-2 >>>>>> is rendering", val)
    return (
        <div>
           Child-2
           <p>Value: {val}</p>
        </div>
    )
}

// export default React.memo(Child2)
export default Child2