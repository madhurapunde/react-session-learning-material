import { useCallback, useEffect, useMemo, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Meal from './Components/Meal'
import { meals } from './Components/data'
import Test from './Components/Test'
import Random from './Components/Random'
import Child1 from './Child1'
import Child2 from './Child2'
import { PostsProvider } from './Components/Posts/PostsContext'
import Counter from './Components/Counter'


function App() {
  const [count, setCount] = useState(0)
  const [toggle, setToggle] = useState(false)
  const names = ["Shamal", "Vamshi", "Raja", "Durga", "Rohit", "Neha", "Upendra"]
  // 1.names
  //2. meal

  // const increment =()=>{
  //   console.log("Increment in Parent")
  //   setCount(prev=>prev+1)
  // }

const increment = useCallback(()=>{
  console.log("with useCallback")
  setCount(prev=>prev+1)

}, [])

  // const complexComputedValue=useMemo(()=>{
  //   console.log("Complex computed value")
  //   return count *2
  // }, [count])

  const complexComputedValue = useMemo(()=>{
    console.log("Complex computed value")
    return count *2
  },[count])

  return (
     <PostsProvider>
      <>
      {/* <input value={count} onChange={e=>setCount(e.target.value)}/>
      <button onClick={handleSearch}>Find</button>
      <p>{count}</p>
      <h1>Vite + React</h1>
     {/* {names.map(name=><p>{name}</p>)} 
      <div className="meal-list">
      {
        meals.map(oneMeal=><Meal abc="somedata" meal={oneMeal}/>)
      }
      </div> */}
      {/* <Test/> */}
      {/* <Random/> */}
      {/* <Child1 inc={increment}/>
      <Child2 val= {complexComputedValue}/>
      <button onClick={()=>setToggle(prev=>!prev)}>Click Here:{toggle}</button> */}
      <Test/>
      {/* <Counter/> */}
    </>
    </PostsProvider>
    
  )
}

export default App
