import React from 'react';
import './Meal.css';
import Test from './Test';

const Meal = (abc) => {
console.log(abc)
  const {meal} = abc
  return (
    <div className="meal-card">
    {abc.abc}
      <h2>{meal.name}</h2>
      <p>Type: {meal.type}</p>
      <p>Calories: {meal.calories}</p>
      <p>Price: ${meal.price.toFixed(2)}</p>
      {/* <Test base={abc.meal.name}/> */}
    </div>
  );
};

export default Meal;