import axios from "axios";
const origin = window.location.href;


const apiService = axios.create({
    baseURL: origin,
    headers: {
      "content-type": "application/json",
      charset: "utf-8",
    //   Authorization: `Bearer ${tokenObject?.accessToken?.accessToken}`,
    },
  });
  
  export const getdataService = (endPoint, data) => {
    return apiService.get(endPoint, { body: data });
  };
//   https://jsonplaceholder.typicode.com/posts