export const meals = [
  { id: 1, name: "Vegetable Stir Fry", type: "Dinner", calories: 350, price: 12.99 },
  { id: 2, name: "Caesar Salad", type: "Lunch", calories: 250, price: 8.99 },
  { id: 3, name: "Oatmeal with Berries", type: "Breakfast", calories: 300, price: 5.99 },
  { id: 4, name: "Grilled Veggie Sandwich", type: "Lunch", calories: 400, price: 9.99 },
  { id: 5, name: "Fruit Salad", type: "Snack", calories: 150, price: 4.99 }
];
