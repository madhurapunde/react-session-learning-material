import React, { useContext } from 'react';
import { PostsContext } from './Posts/PostsContext';

function Test() {
    const { posts, loading } = useContext(PostsContext);

    return (
        <h1>
            {loading ? "Loading..." : (
                <div>
                    {posts.map(post => (
                        <p key={post.id}>{post.title}</p>
                    ))}
                </div>
            )}
        </h1>
    );
}

export default Test;