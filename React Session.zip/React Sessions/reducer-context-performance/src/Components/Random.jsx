function Random(){
    return (<>Random</>)
}
export default Random