import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';
import Test from '../Test';

export const PostsContext = createContext();

export const PostsProvider = ({ children }) => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const getPosts = async () => {
            setLoading(true);
            const res = await axios.get("https://jsonplaceholder.typicode.com/posts");
            const { data, status } = res;
            if (status === 200) {
                setPosts(data);
                setLoading(false);
            }
        };

        getPosts();
    }, []);

    return (
        <PostsContext.Provider value={{ posts, loading }}>
            <Test/>
        </PostsContext.Provider>
    );
};