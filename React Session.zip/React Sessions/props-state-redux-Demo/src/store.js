
//create store for todoList
import { configureStore } from "@reduxjs/toolkit";
import todoReducer  from "./Components/Container/ToDOList/ToDOListSlice";

const store = configureStore({
  reducer: {
    todoList: todoReducer,
    //counter

  },
});

export default store;