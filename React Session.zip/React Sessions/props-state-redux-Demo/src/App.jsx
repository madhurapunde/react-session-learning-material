import React from 'react';
import './App.css'
import { Provider } from 'react-redux';
import store from './store';
import ToDo from './Components/Container/ToDOList/ToDo';

import Dashboard from './Components/Container/Dashboard/Dashboard';
import Car from './Components/Container/Car';
import Dish from './Components/Container/FoodApp/Dish';
import Header from './Components/CommonComponents/Header';


function App() {

  //specific for Dish component
  const dishes = [
    { name: 'Spaghetti Bolognese', cuisine: 'Italian', price: 12.99 },
    { name: 'Sushi Platter', cuisine: 'Japanese', price: 24.99 },
    { name: 'Tacos', cuisine: 'Mexican', price: 9.99 },
  ];

  return (
    <>
    {/* 1. component example:reusable small unit */}
      <Header/>
        {/*2. class-based component */}
        <Dashboard/>

    {/*3. function-based components: props */}
    <h1>Car Inventory</h1>
      <Car brand="Toyota" model="Corolla" year={2021} />
      <Car brand="Honda" model="Civic" year={2020} />
      <Car brand="Ford" model="Mustang" year={2019} />

    {/*4. function-based components: props with Array*/}
    {dishes.map((dish, index) => (
        <Dish key={index} name={dish.name} cuisine={dish.cuisine} price={dish.price} />
      ))}
    {/*5. redux toolkit demo */}
    {/* <Provider store={store}>   
      <ToDo/>
      </Provider> */}
    </>
  )
}

export default App
