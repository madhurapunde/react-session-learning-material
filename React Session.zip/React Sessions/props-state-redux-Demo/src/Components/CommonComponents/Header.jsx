import React from 'react';
import './Header.css';

function Header() {
  return (
    <header className="header">
      <h1 className="header-title">Car Dealership</h1>
      <nav className="header-nav">
        <a href="#home" className="nav-link">Home</a>
        <a href="#inventory" className="nav-link">Inventory</a>
        <a href="#contact" className="nav-link">Contact Us</a>
      </nav>
    </header>
  );
}

export default Header;