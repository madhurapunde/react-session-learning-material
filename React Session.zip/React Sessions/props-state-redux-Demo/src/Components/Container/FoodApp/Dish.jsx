import React, { useState } from 'react';
import './Dish.css';

function Dish({ name, cuisine, price }) {
  const [isAvailable, setIsAvailable] = useState(true);

  const toggleAvailability = () => {
    setIsAvailable(!isAvailable);
  };

  return (
    <div className="dish-card">
      <h2 className="dish-name">{name}</h2>
      <p className="dish-cuisine">Cuisine: {cuisine}</p>
      <p className="dish-price">Price: ${price.toFixed(2)}</p>
      <p className={`dish-status ${isAvailable ? 'available' : 'sold-out'}`}>
        Status: {isAvailable ? 'Available' : 'Sold Out'}
      </p>
      <button className="toggle-button" onClick={toggleAvailability}>
        {isAvailable ? 'Mark as Sold Out' : 'Mark as Available'}
      </button>
    </div>
  );
}

export default Dish;