import React, { useState } from 'react';

function Car({ brand, model, year }) {
  
  const [isAvailable, setIsAvailable] = useState(true);
let flag = true
  const toggleAvailability = () => {
    // setIsAvailable(!isAvailable);
    flag= false
  };

  return (
    <div>
      <h2>{brand} {model}</h2>
      <p>Year: {year}</p>
      <p>Status: {isAvailable ? 'Available' : 'Sold Out'}</p>
      <button onClick={toggleAvailability}>
        {flag ? 'Mark as Sold Out' : 'Mark as Available'}
      </button>
    </div>
  );
}

export default Car;