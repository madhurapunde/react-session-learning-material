import { combineReducers } from "@reduxjs/toolkit";

import toDOSlice from "../Components/Container/ToDOList/ToDOListSlice";

const rootReducer = combineReducers({
    todoList: toDOSlice,
    });


    export default rootReducer;