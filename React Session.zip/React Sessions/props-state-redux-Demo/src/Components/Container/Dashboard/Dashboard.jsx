import React, { Component } from 'react';

class Dashboard extends Component {
    state = {
        details: {
            title: "Car Dashboard",
            description: "This is a simple dashboard demonstrating class-based components in React with car details.",
            items: [
                { id: 1, name: "Tesla Model S", value: "Electric" },
                { id: 2, name: "Ford Mustang", value: "Gasoline" },
                { id: 3, name: "Chevrolet Bolt", value: "Electric" }
            ],
            author:"John Doe",
        }
    };
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //         details: {
    //             title: "Car Dashboard",
    //             description: "This is a simple dashboard demonstrating class-based components in React with car details.",
    //             items: [
    //                 { id: 1, name: "Tesla Model S", value: "Electric" },
    //                 { id: 2, name: "Ford Mustang", value: "Gasoline" },
    //                 { id: 3, name: "Chevrolet Bolt", value: "Electric" }
    //             ]
    //         }
    //     };
    // }

    render() {
        const { title, description, items, ...rest } = this.state.details;
        console.log(rest)
        return (
            <div className="dashboard">
                <h1>{title}</h1>
                <p>{description}</p>
                <ul>
                    {items.map(item => (
                        <li key={item.id}>
                            {item.name}: {item.value}
                        </li>
                    ))}
                </ul>
                <p>Author:{rest.author}</p>
            </div>
        );
    }
}

export default Dashboard;