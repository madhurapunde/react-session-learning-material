import { createSlice } from "@reduxjs/toolkit";

export const todoSlice = createSlice({
    name: "todoList",
    initialState: {
        list: [{ id: 1, title: "Keep learning, Keep Growing", completed: false }],
        mealList:["breakfast", "lunch", "dinner"]
    },
    reducers: {
        addTask: (state, action) => {
        state.list.push(action.payload);
        },
        removeTask: (state, action) => {
        state.list = state.list.filter((task) => task.id !== action.payload);
        },
    },
    });

    export const { addTask, removeTask } = todoSlice.actions;
    export default todoSlice.reducer;