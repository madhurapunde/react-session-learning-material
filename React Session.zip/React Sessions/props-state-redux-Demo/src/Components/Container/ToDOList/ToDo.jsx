import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addTask, removeTask } from './ToDOListSlice'

const ToDo = () => {
    const[task, setTask] = useState('')
    let dispatch = useDispatch()
    let taskListRedux1 = useSelector((state)=>state.todoList)
    // console.log(taskListRedux)
    const {list: taskListRedux, mealList} = taskListRedux1

    useEffect(()=>{
        console.log(taskListRedux)
    }, [])
    

    const handleAddToDoList=()=>{
        dispatch(addTask({id: Math.random(), title: task, completed: false}))
        setTask('')
    }

  return (
    <div>
        <h1>ToDo List</h1>
        <input type="text" placeholder="Add a task" value={task} onChange={(e)=>
        setTask(e.target.value)
        }/>
        <button onClick={handleAddToDoList}>Add Task</button>
        { taskListRedux &&
            taskListRedux.map((task)=>(
               
                <div key={task.id}>
                     <span>
                    <h3>{task.title}</h3>
                    <button onClick={()=>dispatch(removeTask(task.id))}>Delete</button>
                    {/* <button onClick={}>Completed</button> */}
                    </span>
                </div>
                
            ))
        }
      
    </div>
  )
}

export default ToDo
