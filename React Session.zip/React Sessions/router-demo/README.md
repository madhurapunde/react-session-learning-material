# React Router Demo

This project demonstrates the usage of different types of routers provided by the `react-router-dom` library in a React application. The three types of routers included in this demo are:

- **BrowserRouter**: A router that uses the HTML5 history API to keep your UI in sync with the URL.
- **MemoryRouter**: A router that keeps the history of your "URL" in memory (does not read or write to the address bar).
- **HashRouter**: A router that uses the hash portion of the URL (window.location.hash) to keep your UI in sync with the URL.

## Project Structure

```
react-router-demo
├── src
│   ├── components
│   │   └── Home.tsx
│   │   └── About.tsx
│   │   └── Contact.tsx
│   ├── routers
│   │   └── BrowserRouter.tsx
│   │   └── MemoryRouter.tsx
│   │   └── HashRouter.tsx
│   ├── App.tsx
│   └── index.tsx
├── package.json
├── tsconfig.json
└── README.md
```

## Getting Started

To run this demo, follow these steps:

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd react-router-demo
   ```

3. Install the dependencies:
   ```
   npm install
   ```

4. Start the application:
   ```
   npm start
   ```

## Components

- **Home**: Displays a welcome message for the home page.
- **About**: Provides information about the application.
- **Contact**: Contains a contact form or contact information.

## Routers

- **BrowserRouter**: Demonstrates routing using the HTML5 history API.
- **MemoryRouter**: Demonstrates routing with a memory-based history.
- **HashRouter**: Demonstrates routing using the hash portion of the URL.

Feel free to explore the code and modify it to better understand how each router works!