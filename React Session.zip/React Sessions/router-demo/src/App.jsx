import './App.css'
import BrowserRouter from './routers/BrowserRouter';
import MemoryRouter from './routers/MemoryRouter';
import HashRouter from './routers/HashRouter';

function App() {

  return (
    <>
      <div>
      <h1>React Router Demo</h1>
            {/* <h2>Browser Router</h2> */}
            {/* <BrowserRouter /> */}
            {/* <h2>Memory Router</h2> */}
            {/* <MemoryRouter /> */}
            {/* <h2>Hash Router</h2>  */}
             <HashRouter />       
      </div>
      
     
    </>
  )
}

export default App
