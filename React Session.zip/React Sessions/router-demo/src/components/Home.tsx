import React from 'react';
import { Link } from 'react-router-dom';

const Home= () => {
    return (
        <div>
            <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/hashabout">About</Link>
            </li>
            <li>
              <Link to="/hashcontact">Contact</Link>
            </li>
          </ul>
        </nav>
            <h1>Welcome to the Home Page!</h1>
            <p>This is the starting point of our React Router demo application.</p>
        </div>
    );
};

export default Home;