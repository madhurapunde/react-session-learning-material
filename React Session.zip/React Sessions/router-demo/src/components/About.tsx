import React from 'react';

const About = () => {
    return (
        <div>
            <h1>About This Application</h1>
            <p>This application demonstrates the usage of different routers from the react-router-dom library.</p>
            <p>It includes examples of BrowserRouter, MemoryRouter, and HashRouter.</p>
        </div>
    );
};

export default About;