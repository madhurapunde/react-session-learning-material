import React from 'react';
import { MemoryRouter, Routes,Route } from 'react-router-dom';
import Home from '../components/Home';
import About from '../components/About';
import Contact from '../components/Contact';

const MemoryRouter1 = () => {
  return (
    <div>
        <MemoryRouter>
            <Routes>
                <Route path="/" element={<Home/>} />
                <Route path="/memoryabout" element={<About/>} />
                <Route path="/memorycontact" element={<Contact/>} />
            </Routes>
        </MemoryRouter>
      
    </div>
  )
}

export default MemoryRouter1