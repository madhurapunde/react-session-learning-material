import React from 'react';
import { HashRouter, Route, Routes } from 'react-router-dom';
import Home from '../components/Home';
import About from '../components/About';
import Contact from '../components/Contact';

const HashRouter1 = () => {
  return (
    <div>
        <HashRouter>
            <Routes>
                    <Route path="/" element={<Home/>} />
                    <Route path="/hashabout" element={<About/>} />
                    <Route path="/hashcontact" element={<Contact/>} />
                </Routes>
        </HashRouter>
    </div>
  )
}

export default HashRouter1

