import React from 'react';
import { BrowserRouter, Router, Route, Routes } from 'react-router-dom';
import Home from '../components/Home';
import About from '../components/About';
import Contact from '../components/Contact';
import Test from '../components/Test';

const BrowserRouter1 = () => {
  return (
    
        <BrowserRouter>
        <Routes>
            
                <Route path="/" element={<Home/>} />
                <Route path="/about" element={<About/>} />
                <Route path="/contact" element={<Contact/>} />
                <Route path="/test" element={<Test/>}/>
           
        </Routes>
        </BrowserRouter>
  )
}


export default BrowserRouter1;